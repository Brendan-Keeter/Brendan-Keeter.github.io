import ssl
from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import wifi_led, blue_led, config
import uasyncio as asyncio
from machine import UART
from config import *
import network

# === CONFIG ===
# === CONFIG ===
MY_ID = ord('B')  # 'B' as integer
MAX_LEN = 64
MOTOR_ONOFF_TYPE = 0x33
SYSTEM_OFF_TYPE = 0x34
active_status = 1


# UART Setup
uart = UART(2, 9600, tx=17, rx=16)
uart.init(9600, bits=8, parity=None, stop=1, flow=0)

# MQTT Topics (mapped to types)
TOPIC_MAP = {
    0x31: '/EGR314/TEAM203/PITCH',
    0x33: '/EGR314/TEAM203/MOTORON',
    0x34: '/EGR314/TEAM203/OFF',
    0x35: '/EGR314/TEAM203/SENSORERRO',
    0x36: '/EGR314/TEAM203/MOTORERRO',
    0x37: '/EGR314/TEAM203/MQTTERROR',
}


# === Message Utilities ===
def is_valid_message(msg):
    return (
        len(msg) <= MAX_LEN and
        msg[0] == 0x41 and  # 'A'
        msg[1] == 0x5A and  # 'Z'
        msg[-2] == 0x59 and  # 'Y'
        msg[-1] == 0x42     # 'B'
    )


def parse_message(msg):
    from_id = msg[2]
    to_id = msg[3]
    msg_type = msg[4]
    data = list(msg[5:-2])
    return from_id, to_id, msg_type, data
    


def format_ack(from_id, to_id, msg_type, data):
    # AZ = [0x41, 0x5A], YB = [0x59, 0x42]
    return bytes([0x41, 0x5A, to_id, from_id, msg_type] + data + [0x59, 0x42])

def zeroed_message(sender_id):
    # sender_id, 'X', MOTOR_ONOFF_TYPE, 0x00
    return bytes([0x41, 0x5A, sender_id, 0x58, MOTOR_ONOFF_TYPE, 0x00, 0x59, 0x42])



# === MQTT Subscription Callback ===
def sub_cb(topic, msg, retained):
    global active_status

    topic_str = topic.decode()
    msg_str = msg.decode()

    print(f'Topic: "{topic_str}" Message: "{msg_str}" Retained: {retained}')

    if topic_str == '/EGR314/TEAM203/OFF':
        if msg_str == '0':
            active_status = 0
            print("System turned OFF via MQTT.")
            uart.write(zeroed_message(MY_ID))
        elif msg_str == '1':
            active_status = 1
            print("System turned ON via MQTT.")
        else:
            print("Invalid MQTT OFF value:", msg_str)
    else:
        # Forward other MQTT messages to UART
        uart.write(msg)


# === Heartbeat LED ===
async def heartbeat():
    s = True
    while True:
        await asyncio.sleep_ms(500)
        blue_led(s)
        s = not s

# === WiFi Status LED ===
async def wifi_han(state):
    wifi_led(not state)
    print('WiFi is', 'UP' if state else 'DOWN')
    await asyncio.sleep(1)

# === MQTT Connected Callback ===
async def conn_han(client):
    await client.subscribe('/EGR314/TEAM203/OFF', 1)



async def publish_initial_states():
    for msg_type, topic in TOPIC_MAP.items():
        # Default all initial values to 0
        await client.publish(topic, '0', qos=1, retain=True)
        print(f"[INIT PUBLISH] {topic}: 0")




# === OFF Broadcaster ===
async def off_broadcaster():
    while True:
        await asyncio.sleep(3)
        if active_status == 1:
            msg = bytes([0x41, 0x5A, MY_ID, 0x45, SYSTEM_OFF_TYPE, 0x01, 0x59, 0x42])  # 0x45 = 'E' = broadcast
            uart.write(msg)
            print("[OFF MESSAGE SENT]: System active broadcasted.")


# === Real UART Receiver Task ===
# === Real UART Receiver Task with OFF Broadcast ===
async def receiver():
    global active_status
    sreader = asyncio.StreamReader(uart)

    counter = 0  # ms counter for periodic OFF message
    interval_ms = 3000

    while True:
        if active_status == 1 and counter >= interval_ms:
            off_msg = bytes([0x41, 0x5A, MY_ID, 0x45, SYSTEM_OFF_TYPE, 0x01, 0x59, 0x42])  # 'E' = broadcast
            uart.write(off_msg)
            print("[OFF MESSAGE SENT]: System active broadcasted.")
            counter = 0

        if active_status == 0:
            await asyncio.sleep_ms(100)
            continue

        try:
            msg = await asyncio.wait_for(sreader.readexactly(8), 100)
        except asyncio.TimeoutError:
            counter += 100
            continue
        except:
            continue  # Skip other read errors

        if not (
            msg[0] == 0x41 and msg[1] == 0x5A and  # 'AZ'
            msg[6] == 0x59 and msg[7] == 0x42      # 'YB'
        ):
            print("Invalid message framing:", msg)
            continue

        from_id, to_id, msg_type, value = msg[2], msg[3], msg[4], msg[5]

        print(f"\n[UART RECEIVED] From: {chr(from_id)} To: {chr(to_id)} "
              f"Type: 0x{msg_type:02X} Value: {value}")

        if from_id == MY_ID:
            continue  # Ignore own messages

        if to_id != MY_ID and to_id != ord('E'):  # 'E' = broadcast
            uart.write(msg)  # Forward
            continue

        if msg_type == SYSTEM_OFF_TYPE:
            active_status = value
            print("System OFF/ON:", active_status)
            if active_status == 0:
                uart.write(bytes([0x41, 0x5A, MY_ID, 0x58, MOTOR_ONOFF_TYPE, 0x00, 0x59, 0x42]))
            await client.publish(TOPIC_MAP[msg_type], str(value), qos=1)
            continue

        if msg_type == MOTOR_ONOFF_TYPE:
            active_status = value
            print("Motor ON/OFF status:", active_status)
            await client.publish(TOPIC_MAP[msg_type], str(active_status), qos=1)
            continue

        if active_status == 0:
            print("System inactive. Ignoring message.")
            continue

        topic = TOPIC_MAP.get(msg_type)
        if topic:
            await client.publish(topic, str(value), qos=1, retain=True)
            print("Published to MQTT:", topic, value)
        else:
            print("Unknown message type:", msg_type)

        # Send ACK
        ack = bytes([0x41, 0x5A, to_id, from_id, msg_type, value, 0x59, 0x42])
        uart.write(ack)
        print("ACK sent.")




# === SSL Configuration ===
config['server'] = MQTT_SERVER
config['ssid'] = WIFI_SSID
config['wifi_pw'] = WIFI_PASSWORD
config['ssl'] = True

try:
    with open('certs/student_key.pem', 'rb') as f:
        key_data = f.read()
    with open('certs/student_crt.pem', 'rb') as f:
        cert_data = f.read()
    with open('certs/ca_crt.pem', 'rb') as f:
        ca_data = f.read()

    print("✔ Certs loaded:", len(cert_data), len(key_data), len(ca_data))

    ssl_params = {
        "cert": cert_data,
        "key": key_data,
        "cadata": ca_data,
        "server_hostname": MQTT_SERVER,
        "cert_reqs": ssl.CERT_REQUIRED
    }

    config['ssl_params'] = ssl_params

except Exception as e:
    print("SSL certs failed to load:", repr(e))

config['time_server'] = MQTT_SERVER
config['time_server_timeout'] = 10
config['subs_cb'] = sub_cb
config['wifi_coro'] = wifi_han
config['connect_coro'] = conn_han
config['clean'] = True
config['user'] = MQTT_USER
config['password'] = MQTT_PASSWORD

# MQTT Client Setup
MQTTClient.DEBUG = True
client = MQTTClient(config)

# === Main Async Loop ===
async def main():
    wlan = network.WLAN(network.STA_IF)
    print("WiFi connected?", wlan.isconnected())
    print("IP config:", wlan.ifconfig())

    try:
        print("Connecting to MQTT broker...")
        await client.connect()
        print("MQTT connected!")

        await publish_initial_states()

        
    except OSError as e:
        print("MQTT connection failed:", repr(e))
        return

    asyncio.create_task(heartbeat())
    asyncio.create_task(receiver())
    asyncio.create_task(off_broadcaster())


    while True:
        await asyncio.sleep(60)

# === Run It ===
asyncio.create_task(heartbeat())
try:
    asyncio.run(main())
finally:
    client.close()
    asyncio.new_event_loop()
