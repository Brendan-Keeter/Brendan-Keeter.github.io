TEAM = 'EGR314/Team203/'

# MQTT Topics
TOPIC_HB = TEAM + 'heartbeat'
TOPIC_PUB = TEAM + 'PUB'
TOPIC_SUB = TEAM + 'SUB'

# MQTT Server Info
MQTT_SERVER = '52.25.206.167'
MQTT_USER = 'student'
MQTT_PASSWORD = 'egr3x4'

# Wi-Fi Credentials
WIFI_SSID = 'photon'
WIFI_PASSWORD = 'particle'
